﻿// Code-behind file that defines event handlers for the Employee.
using System;
using System.Collections.Specialized; // for class ListDictionary

public partial class Employee : System.Web.UI.Page
{
    // Submit Button adds a new Employee entry to the database,
    // clears the form and displays the updated list of Employee entries
    protected void submitButton_Click( object sender, EventArgs e )
   {
        // execute an INSERT  statement to add a new entry to the      
        // Messages table in the Employee Access Data Source
        EmployeeDataSource.InsertCommand = 
            "INSERT INTO [Employees] (" +

            "[Category]" + ", " +
            "[FirstName]" + ", " +
            "[LastName]" + ", " +
            "[BaseSalary]" + ", " +
            "[TSA]" + // Caution: no , after the last attribute

            ") VALUES (" +

            ToSql(RadioButtonList1.Text) +", " +
            ToSql(FirstnameTextBox.Text) + ", " +
            ToSql(LastnameTextBox.Text) + ", " +
            ToSql(BaseSalaryTextBox.Text) + ", " +
            ToSql(TSATextBox.Text) + // Caution: no , after the last value

            ")";

  
        EmployeeDataSource.Insert();

        // clear the TextBoxes
        clearTextBoxes();

      // update the GridView with the new database table contents
      messagesGridView.DataBind();
   } // submitButton_Click

    // format a string value for SQL
    private string ToSql(string stringValue)
    {
        return "'" + stringValue.Replace("'", "''") + "'";
    }

    // clear the TextBoxes
    private void clearTextBoxes()
    {
        FirstnameTextBox.Text = String.Empty;
        LastnameTextBox.Text = String.Empty;
        RadioButtonList1.SelectedValue = "Faculty";
        BaseSalaryTextBox.Text = String.Empty;
        TSATextBox.Text = String.Empty;

    }

    // Clear Button clears the Web Form's TextBoxes
    protected void clearButton_Click( object sender, EventArgs e )
   {
        clearTextBoxes();
   } // clearButton_Click

    protected void AccessDataSource1_Selecting(object sender, System.Web.UI.WebControls.SqlDataSourceSelectingEventArgs e)
    {

    }

    protected void messagesGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

} // end class Employee
